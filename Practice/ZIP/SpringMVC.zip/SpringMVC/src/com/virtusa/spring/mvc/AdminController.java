package com.virtusa.spring.mvc;

import org.springframework.stereotype.Controller;

@Controller
public class AdminController {

	public AdminController() {
		System.out.println("Admin Controller!!!!!!!!!");
	}

}
