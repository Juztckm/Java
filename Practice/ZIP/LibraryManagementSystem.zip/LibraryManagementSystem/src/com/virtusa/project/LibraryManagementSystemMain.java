package com.virtusa.project;

public class LibraryManagementSystemMain {

	public static void main(String[] args){
	}
}