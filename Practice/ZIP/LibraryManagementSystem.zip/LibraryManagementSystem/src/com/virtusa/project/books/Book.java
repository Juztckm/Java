package com.virtusa.project.books;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.virtusa.project.users.Member;

@Entity
@Table(name = "books")
public class Book {
	
	@Id
	@GeneratedValue( generator = "generatorB",strategy = GenerationType.AUTO)
    @SequenceGenerator(name="generatorB",sequenceName="BOOK_SEQ") 
	private int bookId;
	private String bookName;
	private String author;
	private int edition;
	private double rating;
	@ManyToOne
	@JoinColumn(name="memberId")
	private Member member;
	
	public Member getMember() {
		return member;
	}
	public void setMember(Member member){
		this.member = member;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getEdition() {
		return edition;
	}
	public void setEdition(int edition) {
		this.edition = edition;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}

}
